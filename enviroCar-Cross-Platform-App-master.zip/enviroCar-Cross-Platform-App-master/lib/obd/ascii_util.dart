int hexadecimalToDecimal(String value) {
  return int.parse(value, radix: 16);
}
