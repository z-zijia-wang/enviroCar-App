enum TracksTab {
  local,
  uploaded,
}

enum CreateCarTab {
  hsnTsn,
  attributes,
}

enum BluetoothConnectionStatus {
  ON,
  OFF
}

enum LocationStatus {
  enabled,
  disabled
}

enum TrackType {
  Local,
  Remote
}
