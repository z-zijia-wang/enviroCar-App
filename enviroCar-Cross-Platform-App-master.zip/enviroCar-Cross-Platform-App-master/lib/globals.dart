import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

SharedPreferences preferences;

double deviceHeight;
double deviceWidth;

GlobalKey<ScaffoldMessengerState> scaffoldMessengerState;
