package com.example.envirocar_app_main

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
